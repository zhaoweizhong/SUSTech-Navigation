//
//  FDRootViewController.h
//  FontDiaoDemo
//
//  Created by Lex on 10/7/13.
//  Copyright (c) 2013 FontDiao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FDRootViewController : UICollectionViewController

@end
