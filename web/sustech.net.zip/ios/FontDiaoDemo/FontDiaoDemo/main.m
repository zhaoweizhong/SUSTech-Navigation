//
//  main.m
//  FontDiaoDemo
//
//  Created by Lex on 10/7/13.
//  Copyright (c) 2013 FontDiao. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "FDAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([FDAppDelegate class]));
    }
}
